# Manifest — where everything in this bundle goes

Two folders in this zip mirror your two real repos exactly:

```
slops-os/   -> drop into your Slops-OS repo root (overwrite matching paths)
omen/       -> drop into your omen repo root (overwrite matching paths)
```

New files (safe to just copy in):

- `slops-os/RESOLVER.md`
- `slops-os/Direction/brain-glossary.md` — **this was missing from the first
  version of this bundle.** RESOLVER.md's own text depends on it ("this
  resolver only covers the vocabulary settled in..."). Originally drafted
  as a Project-only doc at `claude/valor-adventures-brain-context.md`,
  which isn't a real repo path — that reference is fixed everywhere it
  appeared (RESOLVER.md and the domain-modeling skill) to point here
  instead. **Do not** place this at a root `CONTEXT.md` — it would collide
  with the existing `context.md` on a case-insensitive filesystem
  (Windows).
- `slops-os/Blueprints/specs/brain-page.schema.json` — location not previously
  confirmed with you; this is a reasonable default (specs folder), move it if
  you want it elsewhere before committing.
- `slops-os/Blueprints/prompts/kickoff.md`
- `slops-os/Blueprints/agent-modules/layer-2-rules.md`
- `slops-os/Blueprints/skills/slops-domain-modeling/SKILL.md`
- `slops-os/Blueprints/skills/slops-wayfinder/SKILL.md`
- `omen/scripts/checks/resolver-conformance.js`

Full-file replacements (overwrite the existing file at this path):

- `slops-os/CLAUDE.md`
- `slops-os/slops-saloon/CLAUDE.md`
- `omen/CLAUDE.md`

No empty folders need creating by hand — git doesn't track empty
directories anyway, so `omen/Direction/state/` and `slops-os/Direction/maps/`
come into existence naturally the moment the first real page or map is
filed there. Nothing to do now.

## Manual edits — small, precise, not included as full-file rewrites

These touch large existing files. Rather than risk transcription drift by
re-emitting entire multi-hundred-line files from memory, here's exactly
what to change by hand (or hand to Claude Code / Codex as a small task):

### `slops-os/Blueprints/skills/SKILL_ROUTING.md`

Add two rows to the "Current SLOPS Skills" table:

```
| `slops-domain-modeling` | Claude | `Layer 0` | `active` | Live vocabulary grilling against real examples before a term enters resolved brain vocabulary. Forked from mattpocock/skills `domain-modeling`, not installed as-is. |
| `slops-wayfinder` | Claude | `Layer 0` | `active` | Multi-session planning map — typed tickets (grilling/prototype/research/task) vs. named fog. Forked from mattpocock/skills `wayfinder`, not installed as-is. |
```

Add four rows to the "Special Routing Rules" trigger-phrase table:

```
| `RESOLVER.md step 9 | unresolvable type | new brain vocabulary` | `slops-domain-modeling` | Mandatory — RESOLVER.md step 9 says "invoke," not "flag." |
| `RESOLVER.md step 10 | fog of war | can't state precisely` | `slops-wayfinder` | Mandatory — puts fog on the map instead of letting it disappear. |
| `grill this term | what do we mean by | define this concept` | `slops-domain-modeling` | Founder-initiated grilling. |
| `map this out | what's actually open | plan across sessions` | `slops-wayfinder` | Founder-initiated planning. |
```

### `slops-os/Blueprints/RESOURCES_INDEX.md`

The "Kickoff modules" line currently describes `kickoff-modules/` as live
and imported. Replace it with: superseded by the unified
`Blueprints/prompts/kickoff.md` — the old per-runtime module system is
archived.

### `omen/scripts/check-sprint-staleness.js`

Add to the `CHECKERS` array:

```js
require("./checks/resolver-conformance"),
```

Add `describe()` cases for kinds `"missing-type"`, `"invalid-type"`,
`"bad-date"`, `"stale-review"` (see the existing cases for
`"buried-known-issue"` etc. as the pattern to match).

### `omen/scripts/checks/README.md`

Add a row to the checker table:

```
| resolver-conformance | page missing/invalid `type:`, or stale past the review window | RESOLVER.md's own audit requirement |
```

### Archive the superseded kickoffs (both repos)

Move to each repo's `Archive/authority-routing/` (same treatment as the
already-archived Claude/Codex-split kickoffs there), with a one-line banner
saying each is superseded by the root `kickoff.md`:

- `slops-os/Blueprints/prompts/kickoff-l0.md`
- `slops-os/slops-saloon/Blueprints/prompts/kickoff-l1.md`
- `omen/Blueprints/prompts/kickoff-l2.md`
- `slops-os/Blueprints/prompts/kickoff-modules/` (whole folder)

## `Direction/maps/` — resolved just now, worth stating explicitly

`slops-wayfinder` is registered `layer: 0` in its own frontmatter — a
company-level skill, not omen-specific — the same as `slops-domain-modeling`
and `RESOLVER.md` itself. So its map output belongs at Slops-OS root's
`Direction/maps/`, not `omen/Direction/maps/`. This wasn't stated this
plainly before; it falls straight out of a decision already made (the
skills' own layer tag), not a new guess.

## What's still genuinely open, not just unfinished

- `brain-page.schema.json`'s folder placement (see above).
- The session-record/ folder in this zip (see below) is history, not
  meant to be committed to either repo — don't copy it into slops-os or
  omen.
