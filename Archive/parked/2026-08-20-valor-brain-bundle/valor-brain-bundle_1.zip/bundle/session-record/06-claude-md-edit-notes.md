# CLAUDE.md edits — all three layers now point at the one kickoff (draft)

Small, targeted edits. Not full rewrites — each layer's `CLAUDE.md` is
already close to the "short pointer" shape you want; this just fixes the
kickoff line and (for omen) adds the two pointers that were still open from
earlier (DBS_INDEX.md, RESOLVER.md).

## Slops-OS root `CLAUDE.md`

Change:

```diff
-Paste `Blueprints/prompts/kickoff-l0.md` to start a root-layer session. The
-kickoff is layer- and capability-named, not vendor-named — it confirms your
-session's actual capabilities and reads Runtime Policy before applying any
-authority.
+Paste `Blueprints/prompts/kickoff.md` to start a session. One kickoff
+file covers all three layers (L0/L1/L2) — it confirms your session's
+actual capabilities, establishes which layer you're in via
+`slops-repo-inspector`, and reads Runtime Policy before applying any
+authority. There is no other kickoff; `kickoff-l0.md` is archived.
```

## Slops Saloon `CLAUDE.md`

Now actually read in full (it wasn't when this was first drafted — that was
a real gap, fixed). Its current kickoff line is:

```text
Paste `Blueprints/prompts/kickoff-l1.md` to start a division-layer session.
The kickoff is layer- and capability-named, not vendor-named — it confirms
your session's actual capabilities and reads Runtime Policy before applying
any authority.
```

Which matches what the edit assumed. Change:

```diff
-Paste `Blueprints/prompts/kickoff-l1.md` to start a division-layer session.
-The kickoff is layer- and capability-named, not vendor-named — it confirms
-your session's actual capabilities and reads Runtime Policy before applying
-any authority.
+Paste the Slops-OS root `../Blueprints/prompts/kickoff.md` to start a
+session. One kickoff file covers all three layers (L0/L1/L2) — it confirms
+your session's actual capabilities, establishes which layer you're in via
+`slops-repo-inspector`, and reads Runtime Policy before applying any
+authority. There is no other kickoff; `kickoff-l1.md` is archived.
```

## Layer 2 rules module — new file

L0 and L1 each have a `Blueprints/agent-modules/layer-N-rules.md` that
`kickoff.md` reads. L2 didn't have one — its rules were inlined directly in
`CLAUDE.md`/`kickoff-l2.md` instead. Built to match the exact format of the
real `layer-0-rules.md` and `layer-1-rules.md` (Path / In scope / Route
elsewhere / Do not / one extra note), pulling the content straight out of
omen's own `CLAUDE.md` and `DBS_INDEX.md` rather than inventing anything:
native mobile as primary surface, free-indefinitely/no-Stripe, the
source-boundary rules (don't treat `slops-saloon/` as the app repo, don't
recreate `Corvus/`), the founder-gated store items, mock-data labeling, and
the ESPN cookie rule. Full file: `layer-2-rules.md` (delivered via
SendUserFile).

`kickoff.md`'s STEP 0.1 table and its safety-gates section were both
updated to point at this file instead of inlining the same rules a second
time, in-line with tonight's own "one source of truth, everything else a
pointer" rule from the metadata-formats discussion.

## omen `CLAUDE.md`

Four changes in one pass, since they're the same document family:

```diff
 ## Read in order before pulling a task
 
 1. `AGENTS.md` (root posture, ownership boundaries, safety rules)
-2. `Direction/context.md` — current operating context
+2. `Blueprints/agent-modules/layer-2-rules.md` (Slops-OS root) — layer
+   scope and do-not-touch list, same pointer L0/L1's CLAUDE.md already give
+3. `DBS_INDEX.md` — repo navigation map (folder purposes, canonical paths,
+   read-first by work type)
+4. `Direction/context.md` — current operating context
 ...
 
 ## Reads on demand
 
 - `Brand/brand-system.md` — voice, palette, type, AAA framework
+- `RESOLVER.md` (Slops-OS root) — read before filing or updating anything
+  in `Direction/state/` or `Direction/maps/`
 ...
 
 ## Kickoff
 
-Paste `Blueprints/prompts/kickoff-l2.md` to start a session — or just run
-the auto-populate flow described in `Blueprints/prompts/HOW-TO-RUN-THE-LOOP.md`.
+Paste the Slops-OS root `Blueprints/prompts/kickoff.md` to start a session
+— it covers all three layers, including omen. There is no separate omen
+kickoff anymore; `kickoff-l2.md` is archived. Auto-populate flow is still
+`Blueprints/prompts/HOW-TO-RUN-THE-LOOP.md`.
```

## Archiving the old kickoffs

Per your own skill-retirement convention (flip status, don't delete —
quarantine instead): move `kickoff-l0.md`, `kickoff-l1.md`, `kickoff-l2.md`
into each repo's `Archive/authority-routing/` alongside the already-archived
Claude/Codex-split kickoffs, with a one-line banner at the top of each
saying it's superseded by the root `kickoff.md`.

`Blueprints/prompts/kickoff-modules/` — its five files' actual content is
now folded into the unified `kickoff.md` (parameterized by layer instead of
L2-only). The folder itself can be archived too, same treatment, since
nothing points to it anymore once this lands.

`RESOURCES_INDEX.md`'s "Kickoff modules" line (currently: "5 shared modules
... imported by both kickoff wrappers at L2") needs its own fix — it should
say "superseded by the unified `kickoff.md`" instead of describing the old,
now-archived wiring as if it's live.
