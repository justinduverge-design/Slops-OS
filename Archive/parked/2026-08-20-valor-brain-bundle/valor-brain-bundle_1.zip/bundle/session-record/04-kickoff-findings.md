# What's actually going on with the kickoffs (findings before the fix)

You're right that something's off, and I found the real shape of it before
touching anything:

**There are three kickoffs today**, not one: `kickoff-l0.md` (SLOPS root),
`kickoff-l1.md` (Slops Saloon), `kickoff-l2.md` (omen — the one you've been
calling "kickoff twelve"). I read all three in full. They're about 90% the
same text — STEP 0 capability check, STEP 0.1 Runtime Policy read, the
safety gates — copy-pasted three times with small per-layer differences
(which queue file to pull from, what's out of scope, which rules module to
read).

**There's also an orphaned `kickoff-modules/` folder** — five files
(`read-first.md`, `pull-task.md`, `plan-approval.md`, `safety-gates.md`,
`done-and-close.md`) clearly built to be the *shared* version of exactly
that duplicated text. `RESOURCES_INDEX.md` claims they're "imported by both
kickoff wrappers at L2" — but `kickoff-l2.md` doesn't reference any of them
anywhere. I checked. They were built for an older Claude/Codex-split kickoff
system that's now sitting in `Archive/authority-routing/.../kickoffs/` as
`kickoff-l0-claude.archived.md` etc. — that system got replaced by today's
single-file-per-layer kickoffs, and the module folder + the
`RESOURCES_INDEX.md` line describing it never got updated when that happened.
That's a real stale-doc bug, the same category your own staleness checker
was built to catch — it's just outside what `check-sprint-staleness.js`
currently scans (`Direction/` and `Blueprints/handoffs/` only, not
`Blueprints/prompts/` or `RESOURCES_INDEX.md`).

So "no more other kickoffs, this should be the only kickoff" isn't just a
naming preference — it's the right fix for a real duplication problem, and
there's already-written content (the orphaned modules) that can become the
real shared step bodies instead of getting thrown away.

## The one thing that's genuinely different per layer

The three kickoffs aren't *identical* underneath the duplication — each
layer really does pull from a different queue file and has a different
scope boundary:

- **L0** — no inbox, pulls from `Direction/TODO.md`, scope is cross-cutting
  doctrine only.
- **L1** — no inbox, pulls from `Direction/current_sprint.md`, scope is
  division/brand/content, no app code.
- **L2 (omen)** — has both `Direction/agent_inbox.md` (pin wins) and
  `Direction/current_sprint.md` (fallback queue), scope is the actual
  product, plus extra rules L0/L1 don't have (native mobile read gate, ESPN
  cookie handling, mock-data labeling).

One more asymmetry worth naming: L0 and L1 each have a `layer-N-rules.md`
module they read as part of their file list. L2 doesn't — its rules are
just inlined directly in `CLAUDE.md`/`kickoff-l2.md`. I didn't build a
`layer-2-rules.md` to force symmetry — that's a bigger normalization than
tonight's ask, so I kept L2's rules as their own block in the unified file
instead, and I'm flagging it as a possible future cleanup rather than doing
it unprompted.

## The fix

One `kickoff.md`, living at Slops-OS root — same pattern you already chose
for `RESOLVER.md`: one canonical file, thin pointers at each layer instead
of full copies. It runs `slops-repo-inspector` first (already step 0 in
every version) to establish which layer's canonical path you're actually
in, then applies a small per-layer parameter block for the handful of real
differences, instead of three near-identical documents. The old
`kickoff-l0.md`/`kickoff-l1.md`/`kickoff-l2.md` get archived (quarantined,
per your own skill-retirement convention — not deleted), and each layer's
`CLAUDE.md` gets a one-line pointer to the single file instead.
