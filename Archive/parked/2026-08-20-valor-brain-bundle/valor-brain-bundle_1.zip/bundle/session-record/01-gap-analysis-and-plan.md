# From DBS to G-Brain — gap analysis and build plan

**Scope:** this is a planning document only. Nothing in `Slops-OS` or `omen` has
been touched. Once you've reviewed and adjusted this, the natural home for
the accepted version is `Direction/decisions/` (the decision) and
`Blueprints/specs/` (the contract) in Slops-OS — I'd propose that as the next
step, not do it unprompted.

## The target, stated plainly

An agent should be able to open your repo cold, read metadata — not prose —
and know: what this file is, what it depends on, what it unlocks, what
standard it has to clear, and whether it's safe to just go do the next thing
or whether it has to stop and ask you. That's what "glide through the files"
means mechanically: traversal by metadata, not by re-reading routing docs
every time.

## What you actually have vs. what that target needs

**You have:** a genuinely good filing system. DBS routes every file to the
right folder by purpose (`Direction/decisions`, `Blueprints/specs`,
`References/patterns`, etc.), `slops-os-markdown.spec.md` enforces file
hygiene, `SKILL_ROUTING.md` catalogs 50 skills, and `slops-graphify` already
graphs the *code* (real output sits in `omen/graphify-out/`). This is a
strong foundation — the gap isn't "you have nothing," it's "the parts don't
talk to each other yet."

**Six concrete gaps between here and there:**

1. **No chain metadata.** Files are filed correctly but don't declare
   relationships. A decision doc doesn't say "this enables skill X"; a skill
   doesn't say "this requires spec Y to exist first." That link only exists
   in a human's head or in prose someone has to read and interpret.
2. **The graph only sees code.** `slops-graphify` walks the codebase, not
   `Direction/`, `Blueprints/`, `References/`. The docs — where the actual
   decisions and standards live — are invisible to it.
3. **No wiki/compounding layer.** DBS is filed correctly but static; nothing
   here behaves like the Karpathy LLM-wiki pattern where an answered
   question becomes a new linked page. Notes don't accumulate cross-links
   over time the way OKF or a wiki does.
4. **No risk tiering.** You just told me you want low-risk steps
   auto-executed. Nothing today defines what counts as low-risk. Without
   that definition, "auto-execute" has no gate and is unsafe to turn on.
5. **No live quality bar.** AAA is being retired but nothing replaces it yet.
   Chain metadata needs *some* answer to "did this clear the bar" before it
   can mark a step done and unlock the next one.
6. **No execution harness.** Even with all the above, something has to
   actually read the graph, find eligible next steps, and either run them or
   surface them. That doesn't exist yet — today "chaining" happens because
   you or an agent reads `RESOURCES_INDEX.md` and figures it out by hand.

None of these are big-repo-rewrite problems. They're additive: a schema, a
graph builder, a risk definition, a replacement standard, and a runner. The
DBS structure stays; it gets a metadata layer on top.

## Proposed frontmatter chain contract (draft — yours to edit)

Extends your existing `slops-os-markdown.spec.md`, not a replacement for it.
Applies to the file types where chaining actually matters first: decisions,
specs, skills, checks/reviews. Everything else in DBS can stay prose-only.

```yaml
---
type: skill              # decision | spec | skill | check | pattern | ...
status: active            # draft | active | blocked | done | retired
risk_tier: low             # low | medium | high — gates auto-execution
requires: []               # paths this depends on existing/being done first
enables: []                # paths this unlocks once status: done
checks_against: []          # path(s) to the standard(s) this must clear
produces: []                # output path(s) this step is expected to create
---
```

`risk_tier` is the field that answers your "auto-execute low-risk steps"
requirement directly — nothing runs unattended without an explicit tier on
the file saying it's allowed to.

## Risk tiers (draft — needs your calibration, not mine)

I can propose a starting split, but this is a founder-taste call, not
something I should invent alone:

- **low** — drafting, linting, research capture, updating an index, running
  an existing check. Reversible, no external effect.
- **medium** — anything that touches product behavior, copy that ships, or
  a decision doc that becomes binding. Agent drafts, you approve.
- **high** — anything touching auth, payments, secrets, infra, or legal —
  already a hard prohibition in your doctrine; stays human-only regardless
  of chain metadata.

## AAA's replacement — this needs to be *your* standard, not mine

You were clear AAA "wasn't good" and want it replaced, but a quality bar
has to reflect your actual current taste, not a framework I generate for
you the same way AAA apparently got generated a few months back. Rather
than me proposing A/B/C-style pillars, I'd suggest we run this as a short,
direct interview — what does "clears the bar" actually mean to you today
for a shipped feature, a piece of copy, a design — and turn your answers
directly into `checks_against`-able criteria. Say the word and we do that
next; I don't want to hand you AAA's replacement in the same unexamined way
AAA itself arrived.

## Phased plan

**Phase 0 — doctrine (no code, low risk):** lock the frontmatter contract
above, define risk tiers with your input, run the standard-replacement
interview. Lands as one `Direction/decisions/` entry + one
`Blueprints/specs/` update.

**Phase 1 — unified graph builder:** extend `slops-graphify` so one run
produces one graph — code nodes (from the existing graphifyy/AST layer) and
doc nodes (from frontmatter + markdown links), sharing one `graph.json` /
`graph.db`. This directly answers your "one unified graph" call — right now
it's two separate things (code graph exists, doc graph doesn't).

**Phase 2 — one real pilot chain, end to end:** since you asked to see the
gap before picking pilot-vs-full, I'd still land on a pilot next — not to
relitigate that choice, but because Phase 1's graph builder needs at least
one real chain with the new frontmatter to prove it parses correctly before
it's pointed at 50 skills at once. Good candidate: your actual next feature
idea, run through decision → spec → skill → check → shipped, fully tagged.

**Phase 3 — retrofit the corpus:** once the pilot proves the schema holds,
apply frontmatter across the existing 50 skills and `Direction/`,
`Blueprints/`, `References/` corpus. Mechanical at this point, scriptable.

**Phase 4 — the runner:** the harness that reads the graph, finds
`status: active` nodes whose `requires` are satisfied, and either executes
(if `risk_tier: low`) or surfaces for approval (medium/high) — this is
"glide through the files" made real, and closes the last gap.

## Open decisions for you

1. Which engine actually merges code + docs in Phase 1 — keep `graphifyy`,
   go ahead with the pending `Understand-Anything` swap eval first, or build
   the doc-side parsing fresh and bolt it onto whichever code engine wins?
2. Who runs the standard-replacement interview, and when — now, or after
   Phase 1 lands so we're not blocking the graph work on it?
3. Confirm the pilot candidate for Phase 2, or name a different real feature
   to run the first chain through.
