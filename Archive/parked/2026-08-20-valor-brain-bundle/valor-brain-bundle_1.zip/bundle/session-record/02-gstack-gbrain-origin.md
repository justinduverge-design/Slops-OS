# The origin, named — and what it means for your build

**Scope:** still planning only. Nothing touched in either repo.

## What gstack and gbrain actually are

They're two different halves of the same person's system, and you've
already half-adopted one of them without the other.

**gstack — the sprint chain.** Slash commands (`/office-hours`,
`/plan-ceo-review`, `/plan-eng-review`, `/review`, `/qa`, `/ship`,
`/retro`...) that run in order: **Think → Plan → Build → Review → Test →
Ship → Reflect.** Each stage writes a doc the next stage reads —
`/office-hours` writes a design doc, `/plan-ceo-review` reads it,
`/plan-eng-review` writes a test plan, `/qa` picks that up. It's explicitly
a *process*, not a tool collection, and it's specialist personas standing
in for a team you don't have.

**You already did this.** `SKILL_ROUTING.md` literally says
`slops-retro` "Replaces gstack learn + retro", `slops-investigate`
"Replaces gstack investigate", `slops-verify` "Replaces gstack browse/qa/
qa-only" — quarantined 2026-06-08. You forked gstack's methodology into
Slops-native versions months ago. The chain concept isn't missing; what's
missing is that it's still a **routing table** (`SKILL_ROUTING.md`,
`RESOURCES_INDEX.md`) a human or agent reads and interprets, not a literal
pipeline with enforced input/output contracts between stages. That's
exactly the ICM refinement you called out — folders with contracts instead
of a table with prose.

**gbrain — the wiki.** This is the piece you correctly identified as
missing, and it's more specific than "notes with frontmatter." Its actual
mechanism:

- **A MECE resolver.** One `RESOLVER.md` decision tree at the root, plus a
  `README.md` per directory that says what goes here / what doesn't. The
  agent reads the resolver *before* filing anything, so the same fact never
  ends up duplicated in three places with three different versions.
- **Two-layer pages.** Every page has a line (`---`) splitting it in two:
  above is **compiled truth** — always current, rewritten on new info,
  starts with a one-paragraph summary. Below is an **append-only timeline**
  — dated, sourced, never rewritten. "What's the state?" reads the top.
  "What happened?" reads the bottom. This is what makes the wiki
  *pre-computed* instead of something an agent re-derives from scratch
  every query — which is the actual point of Karpathy's pattern, sharpened.
- **A database underneath the markdown, not instead of it.** Four
  primitives: an *entity registry* (canonical ID + aliases — "is this the
  same thing?" becomes a DB merge, not a file-merge), an *event ledger*
  (every signal is an immutable, timestamped, sourced record — the
  timeline sections are generated from it), a *fact store* (claims with
  provenance and confidence — when two sources disagree, that's two rows,
  not a hidden contradiction), and a *relationship graph* (typed edges —
  "who enables what" becomes a traversal, not a grep). Markdown is the
  human-facing view; the DB is the source of truth underneath it.
- **Extraction fires on every signal, cheaply.** A lightweight sub-agent
  scans every inbound message/doc for entities and back-links them — async,
  not blocking, cheap model. Corrections get written immediately, no
  batching.

That database-under-markdown detail is why my first draft (parse
frontmatter + links straight into SQLite) was thinner than it needed to be.
Frontmatter should feed a fact store and event ledger, and the graph should
come from that structured layer — markdown stays the readable surface, not
the parse target.

## What "your own, not a copy" actually means here

Don't install gbrain — you don't have gbrain's problem (people, companies,
deals, meeting prep). You have Slops OS's problem: decisions, specs,
skills, checks, product features, one LLC's legal/finance/brand
obligations, and you as the sole executor. So the build is: **take gbrain's
mechanism (resolver, two-layer pages, DB-backed facts/events/entities/
edges, cheap async extraction) and point it at Slops-native content
instead of people/companies/deals** — wired into the DBS taxonomy you
already have, feeding the gstack-derived skill chain you already have,
instead of replacing either.

Concretely, that reframes the frontmatter contract from my last draft. It
was already close (`requires`/`enables`/`checks_against`/`risk_tier`) but
missed the two-layer page split and the DB-underneath piece. Revised
shape for a Slops brain page:

```
[compiled truth — current state, one-paragraph summary, then structured fields]
---
[timeline — append-only, dated, sourced entries]
```

with frontmatter carrying the fact-store-able fields (`type`, `status`,
`risk_tier`, `requires`, `enables`, `checks_against`) at the top, above
even the compiled-truth paragraph — same idea OKF and gbrain both use,
just merged with the chain metadata your auto-execution requirement needs.

## Draft resolver categories for a Slops brain (needs your input, not mine)

gbrain's categories are people/companies/deals/meetings because that's
Garry's world. Yours is different. Starting guess, purely to react to —
tell me what's wrong with it rather than me guessing further:

- `decisions/` — accepted calls, scope gates (you have this: `Direction/decisions`)
- `specs/` — implementation-neutral contracts (you have this: `Blueprints/specs`)
- `skills/` — the sprint-chain stages themselves (you have this: `Blueprints/skills`)
- `features/` — one page per product feature/capability, compiled truth = current state, timeline = how it got there (new — this is closer to gbrain's "deal" or "project" page)
- `checks/` — whatever replaces AAA, one page per standard with pass/fail history (new)
- `people/` or `relationships/` — investors, contractors, vendors, anyone relevant to Valor Adventures LLC as an entity, not just Slops product work (new — this is the part of gbrain's shape you probably *do* still want, just company-scoped not personal-scoped)
- `you/` or `founder/` — the one node gbrain doesn't have and your brain needs: capacity, energy, current focus, the thing that's actually the bottleneck in a one-person company

## Updated open questions

1. Does the resolver-category list above look right, wrong, or missing
   something obvious about how Valor Adventures actually runs?
2. DB layer: SQLite (matches gbrain's embedded/no-server approach,
   simplest to self-host) or something else — any reason to want Postgres/
   Supabase here given omen already runs on Supabase?
3. Extraction: gbrain uses a cheap async sub-agent per signal for
   zero-blocking entity detection. Worth the same pattern here, or is
   manual/on-save extraction (you or the acting agent fills frontmatter
   directly, no separate detector) enough for a single-founder brain where
   volume is much lower than gbrain's 155K-page ingestion problem?
