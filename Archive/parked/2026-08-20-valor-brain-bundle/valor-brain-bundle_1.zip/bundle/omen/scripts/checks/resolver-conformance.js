"use strict";

/**
 * Every brain page's `type:` frontmatter, checked against RESOLVER.md's resolved vocabulary.
 *
 * ## Why this exists
 *
 * RESOLVER.md's own words: "every `type:` is one of the resolved values (not a word that
 * slipped through unflagged)." That sentence isn't checkable by anyone reading it -- it's
 * checkable by something that reads every page's frontmatter and compares it against the same
 * list. This is that something, built as a sibling to the six checkers already in this
 * directory, same contract, same rule: a checker that inspects part of what can drift and
 * calls it clean is worse than no checker.
 *
 * There's no real incident behind this one yet -- unlike its five siblings, which were each
 * built from something that actually went wrong. The brain doesn't have any filed pages yet.
 * This is written ahead of the first real drift instead of after it, on the theory that a
 * schema with no enforcement is just a paragraph everyone means to follow.
 *
 * ## What this does NOT do
 *
 * It never files a page, never invents a `type:` for one that's missing it, and never moves a
 * page whose content no longer matches its declared type -- that's a human call, same as
 * whether a `Done when:` clause was genuinely met. It flags; it does not decide.
 *
 * ## PAGES_DIR
 *
 * RESOLVER.md's "Where it physically lands" question is resolved: `Direction/state/`. DBS's
 * five pillars stay intact -- this sits alongside `Direction/context.md` and
 * `Direction/decision_log.md` as where the ongoing, living pages go.
 */

const fs = require("node:fs");
const path = require("node:path");

const PAGES_DIR = "Direction/state";

// Draft contract from brain-page.schema.json, kept in lockstep with it by hand for now.
// Values not in this list ARE findings, on purpose -- `people` and `trigger-event` are
// deliberately absent (RESOLVER.md steps 7-8: parked, not resolved).
const RESOLVED_TYPES = ["feature", "math-stack", "ball-knowledge", "checks", "founder"];

// Provisional. Needs the same kind of founder calibration risk_tier's low/medium/high split
// got flagged as needing -- not invented here. 90 days is a placeholder, not a decision.
const STALE_AFTER_DAYS = 90;

const FRONTMATTER = /^---\r?\n([\s\S]*?)\r?\n---/;

/**
 * Minimal, dependency-free frontmatter reader -- flat `key: value` and one-line `key: [a, b]`
 * arrays only. Deliberately not pulling in js-yaml or ajv: the existing checkers have zero
 * runtime dependencies, and adding one is a call for Justin to make, not to inherit from a
 * schema draft. If frontmatter ever gets more nested than this, that's the trigger to make
 * that call -- not a reason to half-parse it here.
 */
function parseFrontmatter(text) {
  const m = FRONTMATTER.exec(text);
  if (!m) return null;
  const fields = {};
  for (const line of m[1].split(/\r?\n/)) {
    const kv = /^([A-Za-z_][\w-]*):\s*(.*)$/.exec(line);
    if (!kv) continue;
    const [, key, rawValue] = kv;
    const value = rawValue.trim();
    if (value.startsWith("[") && value.endsWith("]")) {
      fields[key] = value
        .slice(1, -1)
        .split(",")
        .map((s) => s.trim().replace(/^["']|["']$/g, ""))
        .filter(Boolean);
    } else {
      fields[key] = value.replace(/^["']|["']$/g, "");
    }
  }
  return fields;
}

function daysSince(isoDate) {
  const then = new Date(isoDate);
  if (Number.isNaN(then.getTime())) return null;
  return Math.floor((Date.now() - then.getTime()) / (1000 * 60 * 60 * 24));
}

function pageFiles(ctx) {
  const abs = path.join(ctx.root, PAGES_DIR);
  if (!fs.existsSync(abs)) return [];
  return fs
    .readdirSync(abs)
    .filter((n) => n.endsWith(".md"))
    .map((n) => path.join(PAGES_DIR, n));
}

module.exports = {
  id: "resolver-conformance",
  title: "brain pages whose `type:` frontmatter doesn't match RESOLVER.md's resolved vocabulary",
  needs: [],

  appliesWhen(ctx) {
    const files = pageFiles(ctx);
    if (files.length === 0) {
      return { applies: false, reason: `no pages in ${PAGES_DIR}` };
    }
    return { applies: true, detail: `${files.length} page(s) in ${PAGES_DIR}` };
  },

  run(ctx) {
    const findings = [];
    const informational = [];

    for (const relPath of pageFiles(ctx)) {
      const text = ctx.read(relPath);
      const fm = text ? parseFrontmatter(text) : null;

      if (!fm || !("type" in fm) || !fm.type) {
        findings.push({ kind: "missing-type", file: relPath });
        continue;
      }

      if (!RESOLVED_TYPES.includes(fm.type)) {
        findings.push({
          kind: "invalid-type",
          file: relPath,
          value: fm.type,
          resolved: RESOLVED_TYPES,
        });
        continue;
      }

      if (!fm.last_reviewed) {
        informational.push({ key: relPath, status: "no last_reviewed set" });
        continue;
      }

      const age = daysSince(fm.last_reviewed);
      if (age === null) {
        findings.push({ kind: "bad-date", file: relPath, value: fm.last_reviewed });
      } else if (age > STALE_AFTER_DAYS) {
        findings.push({
          kind: "stale-review",
          file: relPath,
          days: age,
          threshold: STALE_AFTER_DAYS,
        });
      }
    }

    return { findings, informational };
  },
};

/*
 * Wiring this in:
 *
 * 1. Create Direction/state/ if it doesn't exist yet (it won't -- no pages have been filed
 *    there. appliesWhen reports "no pages in Direction/state" and skips cleanly until then).
 * 2. Register it in CHECKERS in scripts/check-sprint-staleness.js, alongside the other six.
 * 3. Add describe() cases for "missing-type", "invalid-type", "bad-date", "stale-review" --
 *    same pattern as the existing cases (sprint-item, handoff, buried-known-issue, ...).
 * 4. Add a row to scripts/checks/README.md's checker table:
 *      | resolver-conformance | page missing/invalid `type:`, or stale past the review window
 *        | RESOLVER.md's own audit requirement |
 *
 * Not done here because 1-3 touch files inside the real repo, and nothing gets written there
 * without Justin's say -- this file and the schema are the draft; wiring is the committed
 * step, once he's looked at both.
 */
