---
name: slops-wayfinder
description: Slops-native multi-session planning map. Breaks open-ended work into typed decision tickets (grilling / prototype / research / task) instead of one long undifferentiated backlog, and is explicit about what's a real ticket vs. what's still fog (can't be stated precisely yet). Use when a goal is too big or too vague for current_sprint.md as-is, when RESOLVER.md step 10 fires (can't state precisely what something is), or when picking up work across multiple sessions and the founder needs to see what's open vs. blocked vs. not-yet-real. Forked from mattpocock/skills' wayfinder — not installed as-is. Writes a map/ticket file only — no app code, no deploy.
status: active
skill_type: simple
layer: 0
default_agent: Claude
trigger: none
version: 0.1.0
upstream: none
owner: Justin
---

# Slops Wayfinder Skill

## Purpose

Some work isn't ready for `current_sprint.md` — it's not yet a scoped item, it's a question that
hasn't been asked precisely enough. This skill's job is telling those two apart out loud instead of
letting an unscoped idea sit in the sprint queue pretending to be a ticket, or a real, statable
question sit around as vague fog because nobody wrote it down as a question.

## Why forked, not installed as-is

Upstream wayfinder's ticket types (grilling / prototype / research / task) are generic. This fork
maps each one to an actual Slops skill instead of leaving it as a label:

- **grilling ticket** → routes to `slops-domain-modeling`.
- **task ticket** → routes to `planning-pass`, which turns it into a real `current_sprint.md` item.
- **research ticket** → routes to `pre-build-research`.
- **prototype ticket** → stays a ticket on the map until a `task` ticket is ready to be spun off it.

Upstream also treats "fog of war" as a general planning idea. This fork ties it directly to
RESOLVER.md step 10: a brain page that can't be filed because you can't yet state precisely what it
is isn't a resolver failure, it's a wayfinder fog case — the two documents were written to hand off
to each other on this exact situation, not duplicate the same judgment call in two places.

## When To Use

- A goal is too big or too undefined to become a `current_sprint.md` item as-is.
- RESOLVER.md step 10 fires — you can't yet state precisely what a piece of content is.
- Picking up multi-session work and you need to see what's open, blocked, or still fog before
  choosing what to do next.
- Founder says "map this out," "what's actually open here," or asks what's blocking what.

## When Not To Use

- The work is already a clear, scoped item — just add it to `current_sprint.md` via
  `planning-pass`. Don't make a map for something that's already a ticket.
- What's missing is a definition, not a plan — that's `slops-domain-modeling`.
- HITL vs AFK execution planning for an already-scoped task — that's the sprint/kickoff loop, not
  this skill.

## Required Inputs

- The goal or open question, in the founder's words.
- Whatever's already known: existing tickets, existing `current_sprint.md` items, existing
  glossary/resolver gaps this connects to.

## Steps

1. **List what's actually known** about the goal — real constraints, real decisions already made,
   real open questions.
2. **Split into candidate tickets**, typed as grilling / prototype / research / task. A candidate
   that can't be typed yet is not a ticket — see step 4.
3. **Route each typed ticket** to its real Slops home (see Why Forked above) rather than leaving it
   as an abstract label on the map.
4. **Precision test, per candidate.** Can you phrase this as a concrete question *right now*, even
   if you can't answer it? If yes, it's a ticket (even if blocked). If no, it's fog — name it as fog
   explicitly and leave it off the ticket list. Don't invent a type or a scope to make it look
   resolved.
5. **Mark the frontier.** Which tickets are open and unblocked right now (workable today) vs.
   blocked on another ticket vs. blocked on a founder decision.
6. **Hand off.** Any ticket typed `grilling` goes to `slops-domain-modeling` with the term named.
   Any ticket typed `task` and ready goes to `planning-pass`. Fog stays fog until re-run.

## Output

- A map: known facts, typed tickets (with routing), the frontier (what's actually workable now),
  and an explicit fog list (real but not yet precise enough to be a ticket).
- Not a `current_sprint.md` edit — that's `planning-pass`'s job once a ticket is scoped and ready.

## Safety Rules

- Mapping and routing only. No app code, no deploy, no direct `current_sprint.md` writes.
- A "ticket" that fails the precision test in step 4 does not get written down as a ticket to make
  the map look more complete. An honest fog list beats a padded ticket list.

## Where This Operates

`Layer 0` doctrine. Reads `Direction/current_sprint.md` and `RESOLVER.md` for context; writes a
standalone map to `Direction/maps/` — sibling to `Direction/state/`, not inside it. A ticket map
isn't one of RESOLVER.md's five resolved page types (`feature`/`math-stack`/`ball-knowledge`/
`checks`/`founder`), so it doesn't belong in `Direction/state/` with them; it's planning/roadmap
material, the same kind of thing `Direction/current_sprint.md` already is, which is why it sits
directly under `Direction/` instead. Pairs with `slops-domain-modeling` (grilling tickets),
`planning-pass` (task tickets), and `pre-build-research` (research tickets).

## Change Log

- 2026-08-20: Forked from mattpocock/skills `wayfinder`. Mapped generic ticket types to real Slops
  skills, and tied the fog-of-war distinction explicitly to RESOLVER.md step 10 instead of leaving
  it as a separate, undocumented judgment call. Full frontmatter added, matching the master
  template. Output path settled as `Direction/maps/` (sibling to `Direction/state/`, not inside
  it) after confirming a ticket map isn't one of RESOLVER.md's five resolved page types — and
  confirming, separately, that `slops-graphify`'s output stays at `References/graphify/` rather
  than moving in alongside it, since a generated structural graph and an authored ticket map are
  different things that happen to both be called "a map."
