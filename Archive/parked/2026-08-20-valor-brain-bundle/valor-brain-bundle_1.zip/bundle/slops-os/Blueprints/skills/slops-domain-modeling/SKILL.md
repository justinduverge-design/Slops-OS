---
name: slops-domain-modeling
description: Slops-native live vocabulary grilling. Forces a fuzzy or new term to justify itself against a real example (a real file, a real screenshot, a real decision already on record) before it's allowed into a resolved type. Use when a new concept keeps getting talked around without a settled name, when two people (or two docs) are using the same word for different things, or when RESOLVER.md hits step 9 (a page that can't be classified but can be stated precisely). Forked from mattpocock/skills' domain-modeling — not installed as-is. Produces a CONTEXT.md-format entry and, when the term becomes a new brain-page type, a proposed RESOLVER.md walk-step addition. Writes doctrine only — no app code, no deploy.
status: active
skill_type: simple
layer: 0
default_agent: Claude
trigger: none
version: 0.1.0
upstream: none
owner: Justin
---

# Slops Domain Modeling Skill

## Purpose

Vocabulary doesn't get to enter RESOLVER.md's resolved list by being convenient — it has to survive
being argued against something real. This skill is that argument, run the same way every time
instead of depending on whoever happens to be running the session that night.

## Why forked, not installed as-is

Built from the actual first real run (2026-08-20, the `feature`/`math-stack`/`ball-knowledge`/
`checks`/`founder` glossary now at `Direction/brain-glossary.md`). Three things that
run surfaced that the upstream skill doesn't handle on its own:

1. **No "search first" step.** `math-stack` almost got invented from scratch before it was noticed
   the concept already existed, named, in `Blueprints/playbooks/proprietary-math-stack-playbook.md`.
   Upstream domain-modeling starts from the term; this fork starts from checking whether Slops
   already named the thing under different cover.
2. **No formal exit for "this isn't ready to be resolved."** `trigger event` and `people` were
   correctly parked, not forced — but that call was made by judgment in the moment, not by a rule
   the skill enforces. This fork imports `wayfinder`'s fog-vs-ticket test explicitly (see Steps 5)
   instead of leaving "park it" to whoever's running the session.
3. **No handoff to a resolver.** Upstream produces a glossary and stops. A Slops glossary entry that
   becomes a real `type:` value is useless until RESOLVER.md's walk knows about it — so this fork's
   output contract includes a proposed resolver step, not just a definition.

## When To Use

- A term keeps getting used loosely across sessions or docs and it's starting to cause drift.
- Two docs (or two people, or a doc and a founder statement) use the same word differently.
- RESOLVER.md step 9 fires: a page that doesn't fit any resolved type, but you *can* state
  precisely what it is.
- Founder says "grill this," "what do we actually mean by X," or asks to define new brain
  vocabulary.

## When Not To Use

- The term is already resolved in `Direction/brain-glossary.md` — read it, don't
  re-derive it.
- What's missing isn't a definition, it's a plan — that's `slops-wayfinder`.
- The thing in front of you is fog (RESOLVER.md step 10) — you can't state precisely what it is
  yet. Grilling a term that can't be stated precisely just produces a confident-sounding guess.
  Wait for it to become sharper first.

## Required Inputs

- The fuzzy term or candidate concept, in the founder's own words if possible.
- At least one real example to test it against — a real file, a real screenshot, a real shipped
  decision. Not a hypothetical. If no real example exists yet, this skill can't run yet.
- `Direction/brain-glossary.md` (existing resolved vocabulary, to check for
  collision/reuse before inventing).
- `RESOLVER.md` (to know what's already resolved and where a new type would slot in).

## Steps

1. **Search first.** Check `Direction/brain-glossary.md`, `RESOLVER.md`, and relevant
   `Blueprints/playbooks/` for the concept already existing under a different name. Reusing beats
   inventing (`math-stack`'s actual origin).
2. **State the fuzzy version.** Write down the term as currently used, including any conflicting
   uses if two exist.
3. **Test against a real example.** Does the definition hold when checked against the real file/
   screenshot/decision? If it breaks, the definition is wrong — fix it, don't force the example to
   fit.
4. **Distinguish from neighbors.** Name the closest existing resolved term and state exactly what
   separates them (the way `ball-knowledge` was separated from `math-stack` by "the formula" vs.
   "the judgment call using the formula's output").
5. **Fog-vs-ticket exit check (from wayfinder).** Can you state precisely what this is *right now*,
   even if it's not fully answered? If yes → proceed to resolve or park it explicitly. If no → stop.
   This is fog, not a ticket. Do not force a definition onto it. Say so and leave it.
6. **Resolve or park, explicitly.** Either the term is now resolved (add to glossary, propose a
   RESOLVER.md walk step) or it's parked on purpose (name why, same as `people` and
   `trigger event` were).

## Output

- A new or updated entry in `Direction/brain-glossary.md`'s Language section:
  Term / Definition / _Avoid_ / _Resolved because_ / _Test that confirmed it_.
- If the term becomes a new `type:` value: a proposed new numbered step for RESOLVER.md's walk,
  handed to Justin for approval before it's added — this skill drafts, it doesn't edit RESOLVER.md
  directly.
- If parked: an entry in the glossary's "Flagged, not resolved" section, with the real reason.

## Safety Rules

- Notes and glossary entries only. No app code, no deploy, no editing RESOLVER.md's live walk
  without Justin's approval.
- A term "resolved" without a real example tested against it doesn't count — re-run instead of
  writing it down as settled.

## Where This Operates

`Layer 0` doctrine. Reads/writes `Direction/brain-glossary.md`; proposes (does not
apply) changes to `RESOLVER.md`. Pairs with `slops-wayfinder` for the fog-vs-ticket check and with
`resolver-conformance` downstream, once a new type actually starts getting filed.

## Change Log

- 2026-08-20: Forked from mattpocock/skills `domain-modeling` after the first real Slops run
  (the Valor Adventures brain glossary session). Added search-first step, formal fog-vs-ticket
  exit, and the RESOLVER.md handoff — none of which existed in the upstream skill. Full
  frontmatter added (`status`/`skill_type`/`layer`/`default_agent`/`trigger`/`version`/
  `upstream`/`owner`), matching the master template rather than the thinner
  name/description-only pattern some existing skills use.
