# Layer 2 — Omen (product)

**Path:** `<git-root>/slops-saloon/omen/` (separate GitHub repo:
`justinduverge-design/omen`; canonical path per `DBS_INDEX.md`)

**In scope:**

- The actual product: mobile app (iPhone SwiftUI + Android Kotlin/Compose),
  the secondary web app, backend, tests, deploy, product specs, handoffs,
  prompts, runtime logic
- Native mobile is the primary surface and active authority; new web page
  migrations are paused
- Omen is free indefinitely — no Stripe, subscription, or paywall code

**Route elsewhere:**

- Division strategy, brand custody across products, content + marketing →
  L1 (`slops-saloon/`, ascend one level)
- OS-level skills / agents / doctrine → L0 (ascend two levels)

**Do not** treat the parent `slops-saloon/` folder as the app repo. **Do
not recreate** the retired `Corvus/` subfolder. **Do not edit** `.env`,
secrets, DNS, SSL, Nginx, production infrastructure, Supabase migrations,
package files, or deployment config unless Justin explicitly approves that
exact work.

**Store-related items are founder-gated:** Apple/Google accounts, signing
certificates, provisioning profiles, release configuration, store metadata
submission.

**Mock data must be clearly labeled** — never presented as live advice.
**Never expose ESPN cookies**, anywhere, for any reason.

**Native mobile read gate:** for any native iPhone, Android, mobile
design-system, mobile onboarding, provider-connection, or mobile release
task, read the native mobile spec set (see `CLAUDE.md`) before planning or
code. Do not start native feature work when any of those sources are
missing or conflict — flag the gap instead.
