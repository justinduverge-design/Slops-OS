# Kickoff — Slops OS, all layers

One file. Paste this into any runtime to start a session at **any** of the
three layers — SLOPS OS root (L0), Slops Saloon (L1), or omen (L2). It is
**layer- and capability-named, not vendor-named**: it works for
`claude-code`, `codex`, `cowork`, `api`, or `generic`, and it resolves both
authority and layer from real signals, never from who's reading it or what
folder someone assumes you're in.

There is no other kickoff. `kickoff-l0.md`, `kickoff-l1.md`, and
`kickoff-l2.md` are archived — do not paste those, and if you find a
reference to them anywhere, it's stale; point back here.

---

```text
STEP 0 — CONFIRM SESSION CAPABILITY (do this first, before any read)
  Do NOT infer capability from your vendor name, your model name, or an
  identity module. Identity modules describe POSSIBLE runtime profiles only.
  State explicitly, for THIS session, whether you actually have:
    - file read
    - file write / edit
    - terminal execution
    - git operations
    - network / connector access
    - persistent memory
  Missing or uncertain capability is treated as ABSENT. Uncertainty escalates
  to the founder; it is never resolved by inference.
  Then name which runtime in Runtime Policy you are: claude-code, codex,
  cowork, api, or generic. If you are none of them, you are generic.

STEP 0.1 — ESTABLISH WHICH LAYER YOU ARE IN
  Run slops-repo-inspector before anything else. It tells you your canonical
  path, which of the three layers you're actually working in, branch state,
  and ahead/behind origin. Do not guess your layer from the task description
  or from habit — confirm it from repo-inspector's output.

  Once you know your layer, use its row from this table for every "your
  layer's X" instruction below:

  | Layer | Scope | Queue | Rules module | Read-first module | Out of scope |
  |---|---|---|---|---|---|
  | L0 (SLOPS OS root) | Cross-cutting doctrine, skills/agents/tools/prompts | `Direction/TODO.md`, no inbox | `Blueprints/agent-modules/layer-0-rules.md` | `Blueprints/agent-modules/files-to-read-first-L0.md` | L1 division strategy, L2 app code |
  | L1 (Slops Saloon) | Division strategy, brand custody, content/marketing | `Direction/current_sprint.md`, no inbox | `../Blueprints/agent-modules/layer-1-rules.md` | `../Blueprints/agent-modules/files-to-read-first-L1.md` | L2 app code/deploy/tests, L0 doctrine |
  | L2 (omen) | The actual product — app, backend, frontend, tests, deploy | `Direction/agent_inbox.md` (pin wins) then `Direction/current_sprint.md` | `Blueprints/agent-modules/layer-2-rules.md` (Slops-OS root, reached the same way L0/L1 reach theirs) | native mobile read gate below, when applicable | parent `slops-saloon/` as if it were the app repo; retired `Corvus/` folder |

STEP 0.2 — READ RUNTIME POLICY AND ACTIVE TRUST ASSIGNMENTS
  Read Runtime Policy Section 8 (runtime-policy/v1 and unreviewed-eligibility/v1)
  and Section 9 (active-trust-assignment/v1):
    - L0: Blueprints/agents/AGENT_INDEX.md
    - L1: ../Blueprints/agents/AGENT_INDEX.md
    - L2: L0's Blueprints/agents/AGENT_INDEX.md if reachable from this checkout.
      In a standalone omen checkout where L0 is not available, you have NO
      active assignment by definition — operate at read-only and ask the
      founder before any write.
  - Your default_tier applies until an assignment says otherwise.
  - An empty `assignments: []` list means DEFAULTS ONLY. No assignment means
    no authority above your default_tier.
  - Apply ONLY the authority for the task actually in front of you. Never
    carry authority from a previous task, a previous session, or another item.
  - An assignment is void if session_capability_confirmed is not true, if its
    tier exceeds your max_eligible_tier, or if it has expired.
  - Capability alone grants no authority. A vendor or model name grants
    nothing at all.
  Report which tier you are operating at and why.

READ IN ORDER (use your layer's row from the STEP 0.1 table for the
rules/read-first modules; everything else below is common to all layers)

1. CLAUDE.md / AGENTS.md (this folder)
2. Your runtime identity module, per Runtime Policy:
   Blueprints/agent-modules/identity-{claude-code,codex,cowork,api,generic}.md
   (L1/L2: prefix with the correct relative path to L0)
3. Your layer's rules module (see table)
4. Blueprints/agent-modules/action-posture.md
5. Blueprints/agent-modules/resources-index.md -> Blueprints/RESOURCES_INDEX.md
6. Your layer's read-first module (see table)
7. Blueprints/agent-modules/hard-prohibitions.md
8. Blueprints/agent-modules/session-handoff.md
9. Blueprints/tools/tool-permissions.md (Action Risk Tiers)
10. Direction/facts-of-record.md
11. Direction/decision_log.md (last 5 entries)
12. Your layer's queue file (see table)
13. L2 only: Direction/known_issues.md, then Blueprints/definition-of-done.md,
    Blueprints/playbooks/omen-company-baseline.md,
    Blueprints/playbooks/skill-activation-runbook.md, latest
    Blueprints/handoffs/ entry
14. If this task touches or produces brain content (a feature, a formula, a
    quality bar, a founder-capacity note): RESOLVER.md, at the Slops-OS root
    — read it before filing or updating anything in Direction/state/ or
    Direction/maps/.

PULL TASK
  L0/L1 (no inbox):
    - Select the top item with Status: READY from your layer's queue file,
      ordered by the selection rule in status-model.md. Skip anything whose
      Blocked by: line is not None.
    - If the founder's message already names a specific task, that task wins
      over the queue file — do it.
    - If neither gives a clear task, say so directly and ask. Don't invent one.

  L2 (has inbox):
    1. Read Direction/agent_inbox.md.
    2. If it starts with a pin, that item is your active task — do not
       reorder, skip to PLAN-APPROVAL GATE.
    3. Otherwise read Direction/current_sprint.md and select up to 5 items
       with Status: READY across all lanes, ordered by the selection rule in
       status-model.md.
    4. Organize by what must come first — respect every Blocked by: line.
    5. Overwrite Direction/agent_inbox.md with the new shortlist (never a
       pin). A shortlist is not authority to claim five — record a Claim: on
       the single item you're starting.
    6. Your active task is item #1. If it carries any Blocked by: other than
       None, stop and surface the block. Do not skip ahead.
    7. Soft preference only: Claude leans frontend/docs/spec, Codex leans
       backend/code-volume. Either can pull anything.

  All layers: if your runtime has no queue-wide self-pull authority, do not
  select an item — ask the founder to name one.

PLAN-APPROVAL GATE
  Report, then wait for the founder's confirmation before writing anything:
  1. The task as you understand it, quoted, and where it came from (queue
     item / pin / direct ask)
  2. The tier you're operating at and the assignment that grants it
  3. Blocker check on every "Blocked by" line
  4. Files you expect to touch (full paths) and files you'll avoid
  5. What the user-visible change will look like, one paragraph
  6. Which build/guardrail skills you'll invoke and at what step
     (behavior-changing code defaults to slops-tdd); skills considered but
     N/A, with reason
  7. The tight deterministic verification command (RED before implementation
     for behavior-changing code) plus the broader verification pass before
     declaring done

BUILD — once the founder confirms.

DONE & CLOSE
  1. Satisfy Blueprints/definition-of-done.md for the level you're at.
  2. For behavior-changing code: report intended RED and resulting GREEN,
     then run the verification committed to at plan-approval. Paste output.
  3. Set Status: VERIFIED on the item in your layer's queue file and record
     its Evidence: pointer — or state plainly why it's still open.
  4. Log decisions in Direction/decision_log.md.
  5. If this task touched or produced brain content: run RESOLVER.md's walk,
     file/update the page in Direction/state/ (or Direction/maps/ for a
     wayfinder ticket map), and — once resolver-conformance is registered in
     check-sprint-staleness.js — let it run as part of this step, same as
     the other checkers.
  6. Write a dated handoff in Blueprints/handoffs/YYYY-MM-DD-[topic].md.
  7. L2 only: append to Blueprints/playbooks/skill-usage-ledger.md and
     Blueprints/done/LEDGER.md.
  8. Re-run required verification after all code/evidence files are final,
     then git diff --check.
  9. Commit explicit task paths (never git add -A) with a Conventional
     Commit message. Push the branch once verification is actually done and
     your report is accurate — never on the assumption something passes. Do
     not merge or open/merge a PR — that's Justin's gate.
  10. State a plain complete/incomplete verdict. Don't round up.

Begin now: run STEP 0, STEP 0.1, STEP 0.2, then the reads above, then PULL
TASK immediately. Do not wait for a separate task description — this
message is the task.

SAFETY GATES (apply throughout, every layer — no tier and no assignment
removes these)
- Authorization requires ALL FOUR: the session actually has the capability;
  you hold an active assignment for THIS task; the Action Risk Tier gate is
  satisfied; and every founder, security, provider, and action-level
  approval is satisfied.
- Stop and wait for founder approval at: deploys/production/CI changes, PR
  merges, secret/env edits, database migrations, package-file edits,
  installs (flag the new dependency first), cross-layer file moves
  (L0/L1/L2), naming.
- Destructive, production, DB-write, deployment, and secrets actions each
  need their own ACTION-LEVEL founder approval. General task approval is
  NOT sufficient. Re-ask per action.
- Main-branch merge is founder-only and is never delegated by any
  assignment.
- git push to a feature/worktree branch is allowed only while actively
  assigned full-executor for this task, and only after verification has run
  and your report states an accurate complete/incomplete verdict. Never push
  a "done" claim you haven't checked. No standing branch/commit/push
  authority for any runtime.
- An intended slops-tdd RED before implementation is expected. If a
  guardrail skill (slops-ui-ux-audit, slops-code-review) returns P0
  findings: STOP, do not commit, surface the findings.
- Your layer's specific do-not-touch list and route-elsewhere boundaries are
  in your layer's rules module (see the STEP 0.1 table) — that file is the
  source of truth for them, not this list. Read it; don't assume this
  summary is complete.
- Treat Archive/, _imported/, and old project/worktree copies as
  non-authoritative unless the founder says otherwise.
- Founder approval does not remove hard safety, legal, provider, evidence,
  or irreversible-operation constraints.
```
