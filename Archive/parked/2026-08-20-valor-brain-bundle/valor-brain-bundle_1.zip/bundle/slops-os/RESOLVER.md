# RESOLVER — Valor Adventures / Omen Brain

Read this before filing anything into the brain. If a page doesn't match
a rule below, it doesn't get invented a home — it gets flagged. Every
implementation of this pattern (Tan's G-Brain, Karpathy's original wiki,
DoorDash's Team OS, Ramp's Glass/Dojo) treats an unresolvable page as a
signal the resolver itself needs to grow, not a gap to paper over.

This resolver only covers the vocabulary settled in
`Direction/brain-glossary.md`. It will be wrong or incomplete the moment
something new comes up that isn't in that glossary yet — that's expected,
not a bug.

## Where this file lives — RESOLVED

One copy, at the root of Slops-OS (L0, the company level). Not one per
layer. The vocabulary this resolver governs (`feature`, `math-stack`,
`ball-knowledge`, `checks`, `founder`) is company-wide — omen's content
maps into it, it doesn't generate its own competing taxonomy. This matches
gbrain's actual pattern: one `RESOLVER.md` at the root, plus a thin
`README.md` per directory/layer that says "what goes here" and points back
to the root resolver instead of re-deriving its own rules.

Concretely: `slops-saloon` (L1) and `omen` (L2) each get a short
`README.md` — not their own `RESOLVER.md` — naming what belongs at that
layer and linking back to this file for the actual filing walk. If a layer
ever needs a real taxonomy exception (something genuinely doesn't map to
root vocabulary), that's itself a step-9 "resolver has a gap" case, logged
and flagged here — not a silent fork into a second resolver.

## The walk

Ask these in order. Stop at the first yes.

1. **Is this about code** — an actual function, dependency, API surface,
   cross-file relationship? → Not this resolver. That's `slops-graphify`'s
   job (the code graph), not a brain page.

2. **Is this a shippable, user-facing capability in a product?**
   (MVP Move, Trade Analyzer, Waiver Wire Analyzer, Draft Assistant, or
   their equivalents in a future product) → `type: feature`

3. **Is this a formula or equation a feature runs on?**
   (VORP v2, or a future model like it) → `type: math-stack`

4. **Is this the non-math judgment layer that turns a math-stack number
   into a realistic call** — the "is this actually a good idea" layer,
   not the formula itself? → `type: ball-knowledge`

5. **Is this a quality bar something has to clear before shipping** —
   familiar pattern, modern twist, UX-first? → `type: checks`

6. **Is this about Justin's own capacity, milestones, or availability** —
   not tied to one specific decision, but the standing state of the
   founder? → `type: founder` (name still pending final confirmation —
   see glossary)

7. **Is this about a person or entity other than Justin** (a contractor,
   investor, vendor)? → **Stop. Do not file.** No `people` type exists
   yet — this is parked in the glossary on purpose. Flag it to Justin
   rather than inventing a type to hold it.

8. **Is this the event/moment that causes a check to get applied**
   (not the rule itself — the *when*, not the *what*)? → **Stop. Do not
   file as `checks`.** `trigger event` is a real, separate, still-undefined
   concept. Flag it.

9. **None of the above, but you can state precisely what this is?**
   → This resolver has a real gap. Don't force it into an existing type
   to make the walk end cleanly. **Invoke `slops-domain-modeling`** on the
   term, not just a flag-and-move-on note — that skill exists specifically
   to grill a candidate term against a real example and either resolve it
   (with a proposed new walk step for this file) or park it on purpose,
   the same way `people` and `trigger event` already are.

10. **None of the above, and you can't state precisely what this is yet?**
    → This is fog of war, not a ticket (wayfinder's own distinction: the
    test is whether you can phrase the question precisely *now*, not
    whether you can answer it). Don't file it. Don't invent a type for
    it either. **Invoke `slops-wayfinder`** to place it on the map as
    named fog rather than silently dropping it — a fog item that's never
    written down anywhere doesn't get revisited when it becomes precise
    enough to be a real ticket.

## Where it physically lands — RESOLVED

A new subfolder inside `Direction/`: **`Direction/state/`**. DBS's five
pillars stay intact — `Direction/` already means "current truth," and
`state/` is where the ongoing, living pages (`feature`, `math-stack`,
`ball-knowledge`, `checks`) sit alongside `Direction/context.md`,
`Direction/decision_log.md`, and the rest, instead of getting a
competing sixth pillar.

Concretely: `Direction/state/mvp-move.md` (a `feature` page),
`Direction/state/vorp-v2.md` (a `math-stack` page), and so on — one file
per page, `type:` in frontmatter says which kind.

## check-resolvable — now buildable

Tan's system has an actual audit: a check that walks every page and
confirms the resolver was actually followed, not just written down. With
placement resolved, this is `resolver-conformance` (see
`claude/brain-page-schema-and-checker.md`), written as a seventh checker
in `omen/scripts/checks/`, same contract as the existing six. It verifies,
at minimum: every page in `Direction/state/` has a `type:`; every `type:`
is one of the resolved values (not a word that slipped through
unflagged); and no page has sat unreviewed past a staleness window
(90 days, placeholder pending Justin's calibration). Drafted, not yet
wired into `CHECKERS` or committed to either repo.
