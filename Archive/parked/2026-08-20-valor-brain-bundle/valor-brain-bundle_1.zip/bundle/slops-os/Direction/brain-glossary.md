# Valor Adventures / Omen — Brain Glossary

Captured live, term by term, by grilling each one against a real example
until it either held up or broke. Nothing here was handed down whole —
every entry below was argued into its current shape. Where a name came
from an existing doc (`math-stack`) that's noted; where it didn't exist
until tonight (`ball-knowledge`), that's noted too.

This is the vocabulary source RESOLVER.md's walk depends on — read it
before extending or re-grilling any term here. Placed at
`Direction/brain-glossary.md` rather than a new root `CONTEXT.md`, which
would collide with the existing `context.md` on a case-insensitive
(Windows) filesystem.

## Language

**`type`**:
A required YAML frontmatter field on a brain page. Not a folder. A page's
physical location is still whatever DBS routing already dictates
(`Direction/decisions`, `Blueprints/specs`, etc.) — `type` is what the
resolver and graph actually read to know what kind of thing a page is.
_Resolved because_: DBS folders are organized by pipeline role (current
truth / reference / archived); a second, competing folder system organized
by content kind would have broken that. Keeping `type` as metadata lets
both axes coexist.

**Feature**:
A shippable, user-facing capability inside a product. Examples: MVP Move
of the Week, Trade Analyzer, Waiver Wire Analyzer, Draft Assistant.
_Avoid_: using "feature" for the math or judgment underneath it — those
are `math-stack` and `ball-knowledge`, not features themselves.

**Math-stack**:
The formula/equation a feature runs on. Example: VORP v2. Versioned on its
own; a feature declares a dependency on it rather than restating the
formula. _Source_: not invented tonight — already named in
`Blueprints/playbooks/proprietary-math-stack-playbook.md` ("nflverse owns
baseline math; Slops owns the opinion layer"). Reused rather than
reinvented.
_Test that confirmed it_: Trade Analyzer and MVP Move both run on VORP v2 —
if VORP v2 were filed as a feature, the formula would live in two places
instead of one place both point back to.

**Ball-knowledge**:
The non-math judgment layer that sits on top of a math-stack output and
turns a number into a realistic, actionable call — the part of "best
possible move" that isn't in the equation (what's realistic, how to weigh
this week against the season). Sports slang for deep, genuine understanding
of a game's tactics, history, and players — chosen deliberately over a
generic engineering word like "logic" because it's already Justin's voice
(see also: Trade Room's "the market overreacts," "trade the peak, not the
crash").
_Generalizes_: the shape (tactics + history + actors) isn't sport-bound, so
this stays the literal `type` value across future products rather than
needing a generic parent type with a branded alias.

**Checks**:
The quality bar a screen/feature has to clear before shipping. Confirmed
against a real example (Trade Room, ~10 iterations from "I hated it" to
shipped): the actual rule is **familiar pattern, modern twist, UX-first**
— does this look like an evolution of something people already know how to
use, with your own voice layered on top, not a generic copy and not
something alien. Explicitly replaces AAA, which was found (also live,
tonight) to have never actually governed a real ship decision — the real
gate was always gut reaction to the UI, now made into an actual, statable
rule instead of an unexamined framework.

**Trigger event** _(parked, not resolved)_:
Proposed by Justin, sourced from Garry Tan's own vocabulary, where
"trigger" means the event that kicks a pipeline off (a signal arrives →
enrichment fires) — not the standard something has to meet. Flagged as a
real, separate concept (the *moment* a check gets applied — before ship,
after N iterations, whenever something looks wrong) but not yet defined.
Do not fold into `checks`.

**People** _(parked, not resolved)_:
No real content yet — "the only person is me." Do not build this type
until an actual second person/entity (contractor, investor, vendor) needs
a page. Building it now would be scaffolding without a real object, the
same failure shape AAA had.

**Founder page** _(name not finalized — placeholder "founder" used below)_:
A page about Justin's actual capacity/focus, distinct from
`Direction/decision_log.md` (which already exists, is well-maintained, and
already ties founder context to specific decisions — "founder-gated,"
"founder pushback"). What the decision log doesn't have: a standalone
signal of whether something is on track, independent of any single
decision.
_Deliberately not mood-based._ Not a self-reported energy field (goes
stale silently, a wrong signal is worse than none). Built on milestones and
dates instead — checkable by looking at a calendar, not by trusting a
feeling someone forgot to update.

## Milestone cadence (founder page mechanism)

- **Per-project**: weekly checkpoint.
- **Company-wide** (Valor Adventures): every 3 weeks.
- **Quarterly report**: rolls up the above.
- **Two annual checkpoints**: fiscal half-year, fiscal year-end.
- **Ad hoc**: updated on real milestones that land between fixed checkpoints.
- **Open**: fiscal year start date not yet set — needed before "mid-year"
  and "year-end" are actual dates instead of phrases.

An agent reading this page sees whether something is on-track, overdue, or
untouched, and adjusts behavior accordingly (batch non-urgent questions vs.
actually flag something) — without Justin having to self-report a mood.

## Retired

**"The Gatehouse", "Hall of Records"**: named in `context.md`'s Frontend
Foundation section as UI/auth naming. No longer liked. Do not reuse from
existing docs without checking currency first — a term doesn't stay valid
just because it's written down somewhere in the repo. General rule, not
just about these two names.

## Flagged, not resolved tonight

- **Manifesto Phase 3** ("expand into adjacent domains — personal finance,
  family development"): flagged as stale by Justin, needs its own
  dedicated revisit session (roadmap/strategy work, not resolver
  taxonomy). Do not treat as current scope until revisited.
- Whether `founder` is the right name for the founder/you page — still
  open.
- Fiscal year start date — needed to make the milestone cadence computable.

## How this connects to the larger goal

This glossary is Pocock's `domain-modeling` skill, run live rather than
installed — every term above was argued from a real example (VORP v2,
Trade Room, the actual decision log) rather than accepted on the first
guess. It's the vocabulary layer `RESOLVER.md`'s resolver needed before any
page could be filed. The resolver, the two-layer page format it implies,
and the graph builder are the layers built on top of this one, in the
sessions since.
